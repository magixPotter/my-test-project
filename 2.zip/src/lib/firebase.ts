import { initializeApp } from 'firebase/app'
import { getFirestore } from 'firebase/firestore'
import { getStorage } from 'firebase/storage'

const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY,
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN,
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID,
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET,
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID,
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID,
}

console.log('Firebase Config:', {
  apiKey: firebaseConfig.apiKey ? '✅ есть' : '❌ нет',
  authDomain: firebaseConfig.authDomain ? '✅ есть' : '❌ нет',
  projectId: firebaseConfig.projectId ? '✅ есть' : '❌ нет',
  storageBucket: firebaseConfig.storageBucket ? '✅ есть' : '❌ нет',
  messagingSenderId: firebaseConfig.messagingSenderId ? '✅ есть' : '❌ нет',
  appId: firebaseConfig.appId ? '✅ есть' : '❌ нет',
})

export const app = initializeApp(firebaseConfig)
export const db = getFirestore(app)
export const storage = getStorage(app)